#ifndef __BEEP_H__
#define __BEEP_H__

#include "util.h"

#define FEQUENCY_S 2000 // 每秒两千次

void BEEP_Init();
void BEEP_On(u8 u8seconds);


#endif